import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    API_KEY = os.getenv("KRAKEN_API_KEY", "")
    API_SECRET = os.getenv("KRAKEN_API_SECRET", "")
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-key")
    FERNET_KEY = os.getenv("FERNET_KEY", "")
    RISK_PERCENT = float(os.getenv("RISK_PERCENT", "1.0"))
