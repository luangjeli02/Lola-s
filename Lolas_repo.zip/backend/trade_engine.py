import logging
from kraken_client import add_order
from portfolio_manager import get_equity_usd, compute_size_for_pair, TRADE_CONFIG
from notifier import log_and_notify

def execute_rebalance():
    equity = get_equity_usd()
    if equity is None:
        log_and_notify("Error: cannot determine equity.")
        return False
    for pair, pct in TRADE_CONFIG.items():
        vol = compute_size_for_pair(pair, pct, equity)
        if vol is None or vol <= 0:
            logging.warning(f"Skip {pair}, volume invalid: {vol}")
            continue
        logging.info(f"Placing market buy for {pair} volume={vol}")
        res = add_order(pair, "buy", "market", vol)
        if not res:
            log_and_notify(f"Order failed for {pair}")
        else:
            log_and_notify(f"Order executed for {pair}: volume={vol}")
    return True

def execute_trade_from_payload(payload):
    try:
        pair = payload.get("symbol")
        order = payload.get("order", {})
        side = order.get("side")
        sl = payload.get("stop_loss")
        tp = payload.get("take_profit")
        # size calculation: if payload specifies percent use equity calculation, else fixed
        if order.get("size_mode") == "percent":
            equity = get_equity_usd()
            if equity is None:
                return False
            size = equity * (float(order.get("size_value", 0.0)) / 100.0)
            # convert USD amount to asset volume using ticker
            vol = compute_size_for_pair(pair, (size / equity) * 100.0, equity)
        else:
            vol = float(order.get("size_value", 0.0))
        res = add_order(pair, "buy" if side=="buy" else "sell", "market", vol)
        if res:
            log_and_notify(f"Executed {side} {pair} vol={vol}")
            return True
        else:
            log_and_notify(f"Order failed for {pair}")
            return False
    except Exception as e:
        logging.exception("execute_trade_from_payload failed")
        return False
