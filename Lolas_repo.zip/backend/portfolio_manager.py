from kraken_client import get_balance, get_ticker
import logging

# Simple portfolio configuration: pair -> target percent of equity (USD)
TRADE_CONFIG = {
    "XXBTZUSD": 20,   # BTC/USD
    "XETHZUSD": 15,   # ETH/USD
    "XRPZUSD": 5
}

def get_equity_usd():
    bal = get_balance()
    if bal is None:
        logging.error("Cannot fetch balance.")
        return None
    # Prefer ZUSD if present; otherwise try to estimate from holdings (simple fallback)
    usd = float(bal.get("ZUSD", 0.0))
    # More robust implementations should convert asset balances to USD using Ticker prices
    logging.info(f"Using ZUSD balance as USD equity: {usd}")
    return usd

def compute_size_for_pair(pair, target_pct, equity_usd):
    tk = get_ticker(pair)
    if not tk:
        return None
    # price: last trade closed price
    # take first key in ticker result
    key = list(tk.keys())[0]
    price = float(tk[key]["c"][0])
    target_usd = equity_usd * (target_pct / 100.0)
    volume = target_usd / price
    return round(volume, 8)
