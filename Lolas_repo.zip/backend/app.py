from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
import logging
from logging.handlers import RotatingFileHandler
from dotenv import load_dotenv
import os, json
from trade_engine import execute_rebalance, execute_trade_from_payload
from config import Config
from cryptography.fernet import Fernet

load_dotenv()

app = Flask(__name__, template_folder="../web", static_folder="../web")
app.secret_key = Config.SECRET_KEY

handler = RotatingFileHandler("logs/bot.log", maxBytes=2_000_000, backupCount=5)
handler.setFormatter(logging.Formatter("%(asctime)s — %(levelname)s — %(message)s"))
app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO)

FERNET_KEY = Config.FERNET_KEY
fernet = Fernet(FERNET_KEY.encode()) if FERNET_KEY else None
PAYPAL_STORE_FILE = "paypal.enc"

@app.route("/")
def index():
    paypal_email = ""
    if os.path.exists(PAYPAL_STORE_FILE) and fernet:
        try:
            with open(PAYPAL_STORE_FILE,"rb") as f:
                paypal_email = fernet.decrypt(f.read()).decode()
        except Exception:
            paypal_email = ""
    return render_template("index.html", paypal_email=paypal_email)

@app.route("/settings", methods=["POST"])
def settings():
    try:
        payload = request.json or json.loads(request.data.decode())
        # minimal: save paypal email encrypted
        email = payload.get("paypal")
        if email and fernet:
            with open(PAYPAL_STORE_FILE,"wb") as f:
                f.write(fernet.encrypt(email.encode()))
        return jsonify(status="ok")
    except Exception as e:
        app.logger.exception("settings failed")
        return jsonify(status="error", message=str(e)), 500

@app.route("/start_rebalance", methods=["POST"])
def start_rebalance():
    try:
        ok = execute_rebalance()
        return jsonify(status="ok" if ok else "error")
    except Exception as e:
        app.logger.exception("start_rebalance failed")
        return jsonify(status="error", message=str(e)), 500

@app.route("/webhook", methods=["POST"])
def webhook():
    try:
        data = request.json or json.loads(request.data.decode())
        app.logger.info(f"Webhook received: {data}")
        # accepted signals: rebalance, start_rebalance, trade
        sig = data.get("signal")
        if sig in ("rebalance","start_rebalance"):
            execute_rebalance()
            return jsonify(status="ok")
        if sig in ("trade","order","long_entry","short_entry"):
            ok = execute_trade_from_payload(data)
            return jsonify(status="ok" if ok else "error")
        return jsonify(status="ignored")
    except Exception as e:
        app.logger.exception("webhook error")
        return jsonify(status="error", message=str(e)), 500

if __name__ == '__main__':
    app.run(host=os.getenv('FLASK_HOST','0.0.0.0'), port=int(os.getenv('FLASK_PORT',8080)))
