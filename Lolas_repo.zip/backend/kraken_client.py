import logging
import krakenex
from config import Config

api = krakenex.API()
api.key = Config.API_KEY
api.secret = Config.API_SECRET

def kraken_request(method, args):
    try:
        result = api.query_private(method, args)
        if result.get("error"):
            logging.error(f"Kraken error: {result['error']}")
            return None
        return result.get("result") or result
    except Exception as e:
        logging.exception("Kraken request failed")
        return None

def get_balance():
    res = kraken_request("Balance", {})
    if not res:
        return {}
    return res

def get_ticker(pair):
    res = api.query_public("Ticker", {"pair": pair})
    if res.get("error"):
        logging.error("Kraken ticker error: %s", res["error"])
        return None
    return res.get("result")

def add_order(pair, type_, ordertype, volume, price=None, close=None):
    data = {"pair": pair, "type": type_, "ordertype": ordertype, "volume": str(volume)}
    if price is not None:
        data["price"] = str(price)
    # Note: Kraken requires careful use of close orders; here we send a simple market order.
    return kraken_request("AddOrder", data)

def cancel_all():
    return kraken_request("CancelAll", {})
