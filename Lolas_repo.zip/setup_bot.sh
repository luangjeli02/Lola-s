#!/usr/bin/env bash
set -e
if [ "$EUID" -ne 0 ]; then
  echo "Bitte als root oder mit sudo ausführen"
  exit 1
fi
WORKDIR=/opt/lolas-trading-bot
mkdir -p "$WORKDIR"
cd "$WORKDIR"
# copy bundle files (assume repo already present in working dir)
echo "This setup script assumes you copied the repo into $WORKDIR"
echo "Install Docker if missing..."
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
if ! command -v docker-compose >/dev/null 2>&1; then
  apt-get update && apt-get install -y docker-compose-plugin
fi
echo "Build and start containers..."
docker compose build --no-cache
docker compose up -d
echo "Done. Edit backend/.env and restart: docker compose restart"
