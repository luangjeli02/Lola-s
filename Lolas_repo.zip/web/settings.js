async function save(){
  const paypal = document.getElementById('paypal').value;
  const resp = await fetch('/settings', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({paypal})
  });
  const data = await resp.json();
  alert(data.status);
}

async function startRebalance(){
  const resp = await fetch('/start_rebalance', {method:'POST'});
  const data = await resp.json();
  alert(data.status);
}
